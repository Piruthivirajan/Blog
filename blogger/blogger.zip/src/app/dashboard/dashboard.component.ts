import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'dashboard',
    templateUrl: 'dashboard.html'
})

export class DashboardComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}