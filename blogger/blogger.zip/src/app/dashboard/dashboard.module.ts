import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { MaterialModule } from '../material.module';
import { TopbarComponent } from './topbar/topbar.component';
import { Angular2FontawesomeModule } from 'angular2-fontawesome/angular2-fontawesome';
import {InputTextModule} from 'primeng/primeng';

@NgModule({
  imports: [
    CommonModule,MaterialModule,Angular2FontawesomeModule,InputTextModule
  ],
  exports: [DashboardComponent],
  declarations: [DashboardComponent,TopbarComponent]
})
export class DashboardModule { }
