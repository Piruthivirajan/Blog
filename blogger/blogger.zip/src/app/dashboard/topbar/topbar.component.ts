import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'topbar',
    templateUrl: 'topbar.html'
})

export class TopbarComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}