import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sidebar',
    templateUrl: 'sidebar.html'
})

export class SideBarComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}